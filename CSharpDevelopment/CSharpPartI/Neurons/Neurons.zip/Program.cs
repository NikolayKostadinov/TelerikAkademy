﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Neurons
{
    class Program
    {
        static void Main()
        {
#if DEBUG
            Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif
            long line = long.Parse(Console.ReadLine());
            while (line > -1)
            {
                var number = Convert.ToString(line, 2).PadLeft(32, '0').ToCharArray();
                int startIndex = int.MinValue;
                int endIndex = int.MinValue;

                for (int i = 1; i < number.Length; i++)
                {
                    if (number[i] == '0' && number[i - 1] == '1')
                    {
                        if (startIndex == int.MinValue)
                        {
                            startIndex = i;
                            number[i - 1] = '0';
                        }
                    }
                    else if (startIndex != int.MinValue && number[i] == '1' && number[i - 1] == '0')
                    {
                        endIndex = i;
                    }
                    else
                    {

                    }
                }

                for (int i = 0; i < startIndex; i++)
                {
                    number[i] = '0';
                }
                if (endIndex > startIndex)
                {

                    for (int i = startIndex; i < endIndex; i++)
                    {
                        number[i] = '1';
                    }
                    for (int i = endIndex; i < number.Length; i++)
                    {
                        number[i] = '0';
                    }
                }

                if (startIndex == int.MinValue && endIndex == int.MinValue)
                {
                    Console.WriteLine(0);
                }
                else
                {
                    Console.WriteLine(Convert.ToInt32(string.Join("", number), 2));
                    //Console.WriteLine(string.Join("", number));
                }
                line = long.Parse(Console.ReadLine());
            }
        }
    }
}
