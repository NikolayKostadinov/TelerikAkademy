﻿using System.Collections.Generic;

namespace ConsumingWebServices
{
    public class Articles
    {
        public List<Article> articles { get; set; }
        //public string description { get; set; }
        //public string syndication_url { get; set; }
        //public string title { get; set; }
    }
}